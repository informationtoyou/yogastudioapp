onEvent("info", "click", function( ) {
  setScreen("infoPage");
});
onEvent("returnHomePageFromInfo", "click", function( ) {
  setScreen("homePage");
});
onEvent("signUp", "click", function( ) {
  setScreen("verifiedLog");
  playSound("assets/Relax-1-min---Sunset--Ocean--Moon---Relaxing-Music.mp3", true);
});
onEvent("yogaLegStrength", "click", function( ) {
  setScreen("legYoga");
});
onEvent("yogaBridge", "click", function( ) {
  setScreen("yogaForBridge");
});
onEvent("activitiesOne", "click", function( ) {
  setScreen("yogaActivities");
});
onEvent("returnHomePageViaBridge", "click", function( ) {
  setScreen("yogaActivities");
});
onEvent("home", "click", function( ) {
  setScreen("homePage");
  stopSound("assets/Relax-1-min---Sunset--Ocean--Moon---Relaxing-Music.mp3");
});
onEvent("birdgeYogaUrlOpener", "click", function( ) {
  setScreen("verifyOpenURLScreen");
  open("https://www.youtube.com/watch?v=EZyBkVBUlG4");
});
onEvent("activityReturner", "click", function( ) {
  setScreen("yogaActivities");
});
onEvent("videoLegButton", "click", function( ) {
  setScreen("verifyOpenURLScreen");
  open("https://www.youtube.com/watch?v=CfwmOA8xs3Y");
});
onEvent("privacPolicyRead", "click", function( ) {
  setScreen("privacyPolicyYogaStudioApp");
});
onEvent("ReturnInfoPage", "click", function( ) {
  setScreen("infoPage");
});
onEvent("goActivityFit", "click", function( ) {
  setScreen("yogaActivities");
});
onEvent("breathingActivity", "click", function( ) {
  setScreen("oxygenExersise");
});
onEvent("playToBreath", "click", function( ) {
  playSound("assets/audioofmerandomlybreathingfornoreason.mp3", false);
  stopSound("assets/Relax-1-min---Sunset--Ocean--Moon---Relaxing-Music.mp3");
});
onEvent("stopToBreath", "click", function( ) {
  setScreen("confirmReplayMusicBackContinue");
  stopSound("assets/audioofmerandomlybreathingfornoreason.mp3");
});
onEvent("btnChooseTwo", "click", function( ) {
  playSound("assets/Relax-1-min---Sunset--Ocean--Moon---Relaxing-Music.mp3", true);
});
onEvent("btnChooseOne", "click", function( ) {
  stopSound("assets/Relax-1-min---Sunset--Ocean--Moon---Relaxing-Music.mp3");
});
onEvent("exitToOxygen", "click", function( ) {
  setScreen("yogaActivities");
});
onEvent("continueToTheBridgeDemo", "click", function( ) {
  setScreen("bridgeYogaDemoOne");
});
onEvent("bridgeYogaReadingTextOpener", "click", function( ) {
  setScreen("bridgeYogaDemonstrationOverview");
});
onEvent("exitoOne", "click", function( ) {
  setScreen("yogaForBridge");
});
onEvent("nextPageBridgeYoga", "click", function( ) {
  setScreen("bridgeYogaDemoTwo");
});
onEvent("settings", "click", function( ) {
  setScreen("settingsPage");
});
onEvent("onOne", "click", function( ) {
  playSound("assets/Relax-1-min---Sunset--Ocean--Moon---Relaxing-Music.mp3", true);
});
onEvent("offOne", "click", function( ) {
  stopSound("assets/Relax-1-min---Sunset--Ocean--Moon---Relaxing-Music.mp3");
});
onEvent("signOut", "click", function( ) {
  setScreen("homePage");
  stopSound("assets/Relax-1-min---Sunset--Ocean--Moon---Relaxing-Music.mp3");
});
onEvent("exitFromSettingsToActivities", "click", function( ) {
  setScreen("yogaActivities");
});
onEvent("exitBackForever", "click", function( ) {
  setScreen("yogaActivities");
});
onEvent("goBackWetherYouLikeItOrNot", "click", function( ) {
  setScreen("bridgeYogaDemoOne");
});
onEvent("returnToTheChoosingBridge", "click", function( ) {
  setScreen("yogaForBridge");
});
onEvent("confirmReplayMusicBackContinue", "click", function( ) {
  setScreen("oxygenExersise");
});
onEvent("btnUpdateLogs", "click", function( ) {
  setScreen("updateLog");
});
onEvent("btnExit", "click", function( ) {
  setScreen("infoPage");
});
onEvent("btnTrello", "click", function( ) {
  open("https://trello.com/b/tL33QfxS/yoga-studio-future-updates");
});
onEvent("btnJUSTDOIT", "click", function( ) {
  setScreen("verifyOpenURLScreen");
  open("https://youtu.be/aE3cQiSN6Kk");
});
onEvent("btnGETOUTTAHERE", "click", function( ) {
  setScreen("yogaActivities");
});
onEvent("btnNext", "click", function( ) {
  setScreen("update#1");
});
onEvent("btnPrevious", "click", function( ) {
  setScreen("updateLog");
});
onEvent("btnExitBack", "click", function( ) {
  setScreen("infoPage");
});
onEvent("btnTrelloAgain", "click", function( ) {
  open("https://trello.com/b/tL33QfxS/yoga-studio-future-updates");
});
onEvent("sleepYoga", "click", function( ) {
  setScreen("yogaJumpingJacksActivityPage");
});
